class Tweet:
	
	def __init__(self):
		pass