System Requirements:  
Installation of R  
Twitter Authentication to access API  

# Front-end code for Twitter Sentiment Analysis

ui.R: Contains code for the deign of the front-end  
server.R: Contains code for intgration of the front-end with the backend  
  
  
Sidebar panel:  
1. Category to analyse: textInput  
2. Hashtag: textInput  
3. No. of tweets to search: sliderInput  
 
Main panel:   
Tabs:  
1. Top Trending Tweets Today: table  
2. Word Cloud : wordcloud  
3. Histogram : histogram  
4. Pie Chart : pie chart  
5. Table of tweets : table  
6. Top Tweeters of Hashtag : barplot  
7. Top Hashtags of user : ggplot  
