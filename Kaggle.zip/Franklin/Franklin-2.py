
import pandas as pd
import numpy as np
from sklearn import preprocessing
import random
from sklearn.neural_network import MLPClassifier
import sklearn.svm as svm
from sklearn import preprocessing
from sklearn.cross_validation import cross_val_score, train_test_split
from sklearn import preprocessing,cross_validation,svm,neighbors
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
import matplotlib as plt
from sklearn.neighbors import KNeighborsClassifier
from scipy import stats

from numpy import corrcoef, sum, log, arange
from numpy.random import rand
from pylab import pcolor, show, colorbar, xticks, yticks

from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression

random.seed(90)
print('Random',random.random())
data = pd.read_csv('/Users/harish/Desktop/Details/default of credit card clients.csv',skiprows=1)
print('Core',len(data))
df = data.copy()

def describe_factor(x):
    ret = dict()
    for lvl in x.unique():
        if pd.isnull(lvl):
            ret["NaN"] = x.isnull().sum()
        else:
           ret[lvl] = np.sum(x==lvl)
    return ret

print('Sex')
print(describe_factor(df["SEX"]))


print('Education is ordinnal Keep it, but set, others to NA')
print(describe_factor(df["EDUCATION"]))


df["EDUCATION"] = df["EDUCATION"].map({0: np.NaN, 1:1, 2:2, 3:3, 4:np.NaN, 
    5: np.NaN, 6: np.NaN})
print(describe_factor(df["EDUCATION"]))


print('MARRIAGE 0,3=>NA')
print(describe_factor(df["MARRIAGE"]))


df.MARRIAGE = df.MARRIAGE.map({0:np.NaN, 1:1, 2:0, 3:np.NaN})
print(describe_factor(df.MARRIAGE))


print("Others are quantitative and presents")

print(df.describe())


print(df.isnull().sum())


df.ix[df["EDUCATION"].isnull(), "EDUCATION"] = df["EDUCATION"].mean()
df.ix[df["MARRIAGE"].isnull(), "MARRIAGE"] = df["MARRIAGE"].mean()
print(df.isnull().sum().sum())


dfa=df[[6,7,8,9,10,11]]
dfa=dfa.applymap(lambda x: np.nan if x == -2 else x)
dfa=dfa.applymap(lambda x: np.nan if x == 0 else x)
print(dfa.head())
for i in dfa.columns:
    for j in dfa.columns:
        
       
            
          dfa[i].fillna(dfa[j], inplace=True)
         
print(df.head())

            
dfb=df[[12,13,14,15,16,17,18,19,20,21,22,23]]

dfb=pd.DataFrame(dfb)


print(dfb.head())



dfb=preprocessing.robust_scale(dfb, axis=0, with_centering=True, with_scaling=True, quantile_range=(25.0, 75.0), copy=True)

dfb=pd.DataFrame(dfb)
print(dfb.head())

df=df.drop(['PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6'],axis=1)            


df=df.drop(['BILL_AMT1','BILL_AMT2','BILL_AMT3','BILL_AMT4','BILL_AMT5','BILL_AMT6','PAY_AMT1','PAY_AMT2','PAY_AMT3','PAY_AMT4','PAY_AMT5','PAY_AMT6'],axis=1) 

df[['PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6']]=dfa
df[['BILL_AMT1','BILL_AMT2','BILL_AMT3','BILL_AMT4','BILL_AMT5','BILL_AMT6','PAY_AMT1','PAY_AMT2','PAY_AMT3','PAY_AMT4','PAY_AMT5','PAY_AMT6']]=dfb

dfx=df[df.PAY_0.notnull()]
dfy=df[df.PAY_0.isnull()]

target = 'default payment next month'

predictors = df.columns.drop(['ID','PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6',target])

X = np.asarray(dfx[predictors])
y = np.asarray(dfx['PAY_0'])

print(len(X))

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)


clf= RandomForestClassifier(n_estimators=23, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=100, min_weight_fraction_leaf=0.0, max_features='auto', max_leaf_nodes=None, bootstrap=True, oob_score=True, n_jobs=1, random_state=1, verbose=0, warm_start=False, class_weight=None)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("Random Forest",accuracy)

dft0= clf.predict(dfy[predictors])

y = dfx['PAY_2']

print(len(X))

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

scaler = StandardScaler()  
scaler.fit(X_train)  
X_train = scaler.transform(X_train)  
X_test = scaler.transform(X_test)  

clf= RandomForestClassifier(n_estimators=23, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=100, min_weight_fraction_leaf=0.0, max_features='auto', max_leaf_nodes=None, bootstrap=True, oob_score=True, n_jobs=1, random_state=1, verbose=0, warm_start=False, class_weight=None)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("Random Forest",accuracy)

dft2= clf.predict(dfy[predictors])


y = np.asarray(dfx['PAY_3'])

print(len(X))

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)


clf= RandomForestClassifier(n_estimators=23, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=100, min_weight_fraction_leaf=0.0, max_features='auto', max_leaf_nodes=None, bootstrap=True, oob_score=True, n_jobs=1, random_state=1, verbose=0, warm_start=False, class_weight=None)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("Random Forest",accuracy)

dft3= clf.predict(dfy[predictors])


y = np.asarray(dfx['PAY_4'])

print(len(X))

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)


clf= RandomForestClassifier(n_estimators=23, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=100, min_weight_fraction_leaf=0.0, max_features='auto', max_leaf_nodes=None, bootstrap=True, oob_score=True, n_jobs=1, random_state=1, verbose=0, warm_start=False, class_weight=None)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("Random Forest",accuracy)

dft4= clf.predict(dfy[predictors])


y = np.asarray(dfx['PAY_5'])

print(len(X))

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)


clf= RandomForestClassifier(n_estimators=23, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=100, min_weight_fraction_leaf=0.0, max_features='auto', max_leaf_nodes=None, bootstrap=True, oob_score=True, n_jobs=1, random_state=1, verbose=0, warm_start=False, class_weight=None)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("Random Forest",accuracy)

dft5= clf.predict(dfy[predictors])


y = np.asarray(dfx['PAY_6'])

print(len(X))

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)


clf= RandomForestClassifier(n_estimators=23, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=100, min_weight_fraction_leaf=0.0, max_features='auto', max_leaf_nodes=None, bootstrap=True, oob_score=True, n_jobs=1, random_state=1, verbose=0, warm_start=False, class_weight=None)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("Random Forest",accuracy)

clf=MLPClassifier(activation='relu', alpha=1e-05, batch_size='auto',
       beta_1=0.9, beta_2=0.999, early_stopping=False,
       epsilon=1e-08, hidden_layer_sizes=(5,2), learning_rate='constant',
       learning_rate_init=0.001, max_iter=300, momentum=0.9,
       nesterovs_momentum=True, power_t=0.5, random_state=1, shuffle=True,
       solver='adam', tol=0.001, validation_fraction=0.1, verbose=False,
       warm_start=False)


clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("ANN",accuracy)


dft6= clf.predict(dfy[predictors])

dft0 = pd.DataFrame(dft0)

dft0.columns=['PAY_0']

dft2 = pd.DataFrame(dft2)

dft2.columns=['PAY_2']

dft3 = pd.DataFrame(dft3)

dft3.columns=['PAY_3']

dft4 = pd.DataFrame(dft4)

dft4.columns=['PAY_4']

dft5 = pd.DataFrame(dft5)

dft5.columns=['PAY_5']

dft6 = pd.DataFrame(dft6)

dft6.columns=['PAY_6']
dfp=dft0


dfp=dfp.join(dft2)
dfp=dfp.join(dft3)
dfp=dfp.join(dft4)
dfp=dfp.join(dft5)
dfp=dfp.join(dft6)



print(dfp)

predictors2 = df.columns.drop(['PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6'])

dfy.drop(['PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6'], axis=1)



dfy1=dfy.reset_index(drop=True)
dfy1[['PAY_0','PAY_2','PAY_3','PAY_4','PAY_5','PAY_6']]=dfp

dfx1=dfx.reset_index(drop=True)
df=dfx1.append(dfy1)

print(df.head())


#df1=data.copy()

#print(df1.columns)
print('Dimensions',len(df))














describe_factor(df[target])

predictors = df.columns.drop(['ID', target])
X = np.asarray(df[predictors])
y = np.asarray(df[target])




data=X[:300,:].transpose()



R = corrcoef(data)

pcolor(R)
colorbar()
yticks(arange(0,21),range(0,22))
xticks(arange(0,21),range(0,22))
show()




X = X
Y =y

model = LogisticRegression()
rfe = RFE(model, 1)
fit = rfe.fit(X, Y)
print("Num Features:",fit.n_features_)
print("Selected Features:",fit.support_)
print("Feature Ranking: ",fit.ranking_)

X=pd.DataFrame(X)

X1=X[[1,3,4,6,11,18]]








X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)

scaler = StandardScaler()   
scaler.fit(X_train)  
X_train = scaler.transform(X_train)  
X_test = scaler.transform(X_test)  
#
clf=svm.LinearSVC(random_state=0)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("SVM using Linear SVC accuracy",accuracy)


clf=DecisionTreeClassifier(random_state=0)
clf.fit(X_train,y_train)
#
accuracy=clf.score(X_test,y_test)
print("Decision Tree accuracy",accuracy)


clf= RandomForestClassifier(n_estimators=23, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=100, min_weight_fraction_leaf=0.0, max_features='auto', max_leaf_nodes=None, bootstrap=True, oob_score=True, n_jobs=1, random_state=1, verbose=0, warm_start=False, class_weight=None)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("Random Forest",accuracy)



clf = KNeighborsClassifier(n_neighbors=14)
clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print('KNN Accuracy',accuracy)


clf=MLPClassifier(activation='relu', alpha=1e-05, batch_size='auto',
       beta_1=0.9, beta_2=0.999, early_stopping=False,
       epsilon=1e-08, hidden_layer_sizes=(5,2), learning_rate='constant',
       learning_rate_init=0.001, max_iter=300, momentum=0.9,
       nesterovs_momentum=True, power_t=0.5, random_state=1, shuffle=True,
       solver='adam', tol=0.001, validation_fraction=0.1, verbose=False,
       warm_start=False)


clf.fit(X_train,y_train)
##
accuracy=clf.score(X_test,y_test)
print("ANN",accuracy)


